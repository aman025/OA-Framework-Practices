/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package xxnewemp.oracle.apps.per.selfservice.employee.webui;

//import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAImageBean;
import oracle.apps.fnd.framework.webui.beans.OARawTextBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
//import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;

import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageFileUploadBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;

import oracle.cabo.ui.UIConstants;

import oracle.jbo.domain.BlobDomain;


import oracle.jbo.html.WebBean;

import org.apache.commons.codec.binary.Base64;

import xxnewemp.oracle.apps.per.selfservice.employee.server.XXEmpDetAMImpl;
import xxnewemp.oracle.apps.per.selfservice.employee.server.XXEmpDetEOVORowImpl;

/**
 * Controller for ...
 */
public class XXEmpReviewCO extends OAControllerImpl {
    public static final String RCS_ID = "$Header$";
    public static final boolean RCS_ID_RECORDED = 
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

    /**
     * Layout and page setup logic for a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
        super.processRequest(pageContext, webBean);
        XXEmpDetAMImpl am = 
            (XXEmpDetAMImpl)pageContext.getApplicationModule(webBean);
        //        if (am != null) {
        //            OAViewObject vo = (OAViewObject)am.findViewObject("XXEmpDetEOVO1");
        //            String EmpNu = pageContext.getParameter("empNoMST");
        //            vo.setWhereClauseParam(0, EmpNu);
        //            vo.executeQuery();
        //        }
        OAMessageStyledTextBean Employeeid1 = 
            (OAMessageStyledTextBean)webBean.findChildRecursive("empNoMST");
        String Employeeid = (String)Employeeid1.getValue(pageContext);
        BlobDomain blobVal = null;
        if (Employeeid == null || "".equals(Employeeid)) {

            if (pageContext.getSessionValue("empNoMST") != null && 
                !"".equals(pageContext.getSessionValue("empNoMST"))) {
                Employeeid = (String)pageContext.getSessionValue("empNoMST");
            }
        }
        //        String Sno = (String)empMST.getValue(pageContext);
        //        setImage(pageContext, webBean, Sno);
        //        executeVO(pageContext, webBean, Sno);
        //        if (empMST == null || "".equals(empMST)) {
        //
        //            if (pageContext.getSessionValue("Employeeid") != null && 
        //                !"".equals(pageContext.getSessionValue("Employeeid"))) {
        //                empMST = (Number)pageContext.getSessionValue("Employeeid");
        //            }
        //        }

        //         if(Employeeid!=null && !"".equals(Employeeid) ){
        //            OARawTextBean ImgNew = 
        //                (OARawTextBean)webBean.findIndexedChildRecursive("imgDataRT");
        //            OAViewObject attachmentEOVO = 
        //                (OAViewObject)am.findViewObject("XXEmpDetEOVO1");
        //
        //            if (attachmentEOVO != null) {
        //                attachmentEOVO.setWhereClause(null);
        //                attachmentEOVO.setWhereClauseParams(null);
        //                attachmentEOVO.setWhereClause("Employeeid=:1");
        //                attachmentEOVO.setWhereClauseParam(0, Employeeid);
        //                attachmentEOVO.executeQuery();
        //            }
        //
        //            int count = attachmentEOVO.getRowCount();
        //            
        //            if (count > 0) {
        //                XXEmpDetEOVORowImpl rowimpl = 
        //                    (XXEmpDetEOVORowImpl)attachmentEOVO.first();
        //                if (rowimpl != null) {
        //                    blobVal = rowimpl.getEmpphoto();
        //                    if (blobVal != null) {
        //                        byte[] encoded = getEncodedBytes(blobVal);
        //                        ImgNew.setText(ImgNew.getText().replace("XXIMG", 
        //                                                                "data:image/jpeg;base64," + 
        //                                                                new String(encoded)));
        //                    }
        //                }
        //            }
    }

    /**
     * Procedure to handle form submissions for form elements in
     * a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processFormRequest(OAPageContext pageContext, 
                                   OAWebBean webBean) {
        super.processFormRequest(pageContext, webBean);
        OAApplicationModule am = pageContext.getApplicationModule(webBean);

        if (pageContext.getParameter("saveBTN") != null) {
            // this is calling apply method
            am.invokeMethod("apply");
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpSummaryPG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);
            /* for throwing confirmation message*/
            throw new OAException("Details Saved Successfully", 
                                  OAException.CONFIRMATION);
        }
        OAHeaderBean pageCreateEmpHder = 
            (OAHeaderBean)webBean.findChildRecursive("createRN");
        if (pageContext.getParameter("cancleBTN") != null) {
            am.invokeMethod("rollbackChanges");
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpSummaryPG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);
            if ("Review Employee Details".equals(pageCreateEmpHder.getText())) {
                Connection conn = 
                    pageContext.getApplicationModule(webBean).getOADBTransaction().getJdbcConnection();
                //                String sqlStr = "ALTER SEQUENCE OAP_EMP_SEQ INCREMENT BY -1 ";
                String sqlStr2 = "ALTER SEQUENCE EMP_SL_NP INCREMENT BY -1 ";
                PreparedStatement stmt;
                //                try {
                //                    stmt = conn.prepareStatement(sqlStr);
                //                    stmt.executeQuery();
                //                    sqlStr = "select OAP_EMP_SEQ.nextval from dual ";
                //                    stmt = conn.prepareStatement(sqlStr);
                //                    stmt.executeQuery();
                //                    sqlStr = "ALTER SEQUENCE OAP_EMP_SEQ INCREMENT BY 1 ";
                //                    stmt = conn.prepareStatement(sqlStr);
                //                    stmt.executeQuery();
                //                } catch (SQLException e) {
                //                    ;
                //                }
                PreparedStatement stmt2;
                try {
                    stmt2 = conn.prepareStatement(sqlStr2);
                    stmt2.executeQuery();
                    sqlStr2 = "select EMP_SL_NP.nextval from dual ";
                    stmt2 = conn.prepareStatement(sqlStr2);
                    stmt2.executeQuery();
                    sqlStr2 = "ALTER SEQUENCE EMP_SL_NP INCREMENT BY 1 ";
                    stmt2 = conn.prepareStatement(sqlStr2);
                    stmt2.executeQuery();
                } catch (SQLException e) {
                    ;
                }

                //                if (pageContext.getParameter("uploadBTN") != null) {
                //                    upLoadFile(pageContext, webBean);
                //                    OAException confirmation =
                //                        new OAException("Photo Uploaded Successfully",
                //                                        OAException.CONFIRMATION);
                //                    pageContext.putDialogMessage(confirmation);
                //                }
            }
        }
    }
    //
    //    private void executeVO(OAPageContext pageContext, OAWebBean webBean, 
    //                           String Sno) {
    //        XXEmpDetAMImpl am = 
    //            (XXEmpDetAMImpl)pageContext.getApplicationModule(webBean);
    //        if (am != null) {
    //            String[] voList = 
    //            { "XXEmpDetEOVO1"};
    //            for (int step = 0; step < voList.length; step++) {
    //                OAViewObject vo = 
    //                    (OAViewObject)am.findViewObject(voList[step]);
    //                vo.setWhereClause(null);
    //                vo.setWhereClauseParams(null);
    //                vo.setWhereClauseParam(0, Sno);
    //                vo.executeQuery();
    //            }
    //        }
    //    }
    //
    //        public BlobDomain getBlobData(OAPageContext pageContext, 
    //                                       OAWebBean webBean, String Sno) {
    //            BlobDomain img = null;
    //            XXEmpDetAMImpl am = 
    //                (XXEmpDetAMImpl)pageContext.getApplicationModule(webBean);
    //            if (am != null) {
    //                OAViewObject vo = (OAViewObject)am.findViewObject("XXEmpDetEOVO1");
    //                vo.setWhereClause(null);
    //                vo.setWhereClauseParams(null);
    //                vo.setWhereClauseParam(0, Sno);
    //                vo.executeQuery();
    //                vo.reset();
    //                if (vo.getRowCount() > 0) {
    //                    OARow row = (OARow)vo.next();
    //                    img = (BlobDomain)row.getAttribute("Empphoto");
    //                }
    //            }
    //            return img;
    //        }

    public byte[] getEncodedBytes(BlobDomain data) {
        byte[] blobAsBytes = data.toByteArray();
        Base64 codec = new Base64();
        byte[] encoded = Base64.encodeBase64(blobAsBytes);
        return encoded;
    }
    //
    //    private void setImage(OAPageContext pageContext, OAWebBean webBean, 
    //                          String Employeeid) {
    //        byte[] imageData = null;
    //
    //        BlobDomain imgBlobData = getBlobData(pageContext, webBean, Employeeid);
    //        if (imgBlobData != null) {
    //            imageData = getEncodedBytes(imgBlobData);
    //        }
    //        OAImageBean personImage = 
    //            (OAImageBean)webBean.findChildRecursive("item1");
    //        if (imageData != null) {
    //            personImage.setAttributeValue(UIConstants.SOURCE_ATTR, 
    //                                          "data:image/jpeg;base64," + 
    //                                          new String(imageData));
    //        } else {
    //            personImage.setAttributeValue(UIConstants.SOURCE_ATTR, 
    //                                          "/OA_MEDIA/emploee_deafult_image.gif");
    //        }
    //    }

}
