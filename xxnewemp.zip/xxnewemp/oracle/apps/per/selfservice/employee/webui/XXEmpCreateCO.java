/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package xxnewemp.oracle.apps.per.selfservice.employee.webui;

//import com.sun.xml.internal.messaging.saaj.util.Base64;

//import java.io.ByteArrayInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;

import java.sql.Connection;

//import javax.servlet.ServletOutputStream;

//import javax.servlet.ServletOutputStream;

//import javax.servlet.http.HttpServletResponse;
 import oracle.apps.xdo.oa.schema.server.TemplateHelper;

//import oracle.apps.xdo.oa.schema.server.TemplateHelper;

import javax.servlet.ServletOutputStream;

//import Xdo.oa.schema.server.TemplateHelper;


//import oa.schema.server.TemplateHelper;

//import oa.schema.server.TemplateHelper;

import oracle.cabo.ui.data.DataObject;

//import oracle.help.common.xml.XMLNode;

import oracle.jbo.RowSetIterator;
import oracle.jbo.domain.BlobDomain;

import oracle.jbo.domain.Number;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OraclePreparedStatement;

import java.sql.PreparedStatement;

import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADataBoundValueViewObject;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OABodyBean;
import oracle.apps.fnd.framework.webui.beans.OAImageBean;
import oracle.apps.fnd.framework.webui.beans.OARawTextBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;

//import oracle.apps.xdo.template.RTFProcessors;

//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;

//import javax.servlet.http.HttpServletResponse;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;

import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OANavigation;
import oracle.apps.fnd.framework.webui.beans.layout.OACellFormatBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageFileUploadBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.nav.OANavigationBarBean;
import oracle.apps.fnd.framework.webui.beans.nav.OAPageButtonBarBean;
import oracle.apps.fnd.framework.webui.beans.nav.OATrainBean;

//import oracle.cabo.ui.data.DataObject;

import oracle.jbo.Row;

import oracle.jbo.domain.BlobDomain;
//import oracle.jbo.domain;
//import org.apache.commons.codec.binary.Base64;

//import org.omg.CORBA_2_3.portable.InputStream;

//import org.apache.commons.codec.binary.Base64;

//import org.apache.commons.codec.binary.Base64;

//import oracle.xml.parser.v2.XMLNode;

import oracle.xdo.parser.v2.XMLNode;

import oracle.xdo.XDOException;
import oracle.xdo.template.FOProcessor;
import oracle.xdo.template.RTFProcessor;

import org.apache.commons.codec.binary.Base64;

import xxemp.oracle.apps.per.selfservice.employee.server.XXEmpEOVOImpl;

import xxnewemp.oracle.apps.per.selfservice.employee.server.XXEmpDetAMImpl;
import xxnewemp.oracle.apps.per.selfservice.employee.server.XXEmpDetEOVOImpl;
import xxnewemp.oracle.apps.per.selfservice.employee.server.XXEmpDetEOVORowImpl;
import xxnewemp.oracle.apps.per.selfservice.employee.server.XXSpel1VOImpl;
import xxnewemp.oracle.apps.per.selfservice.employee.server.XXSpel1VORowImpl;

/**
 * Controller for ...
 */
public class XXEmpCreateCO extends OAControllerImpl {
    public static final String RCS_ID = "$Header$";
    public static final boolean RCS_ID_RECORDED = 
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

    /**
     * Layout and page setup logic for a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
        super.processRequest(pageContext, webBean);
        //        BlobDomain blobVal = null;
        //        String personIdFV = pageContext.getParameter("EmpNum");
        OABodyBean bodyBean = (OABodyBean)pageContext.getRootWebBean();
        String javaS = "javascript:window.history.forward(1);";
        bodyBean.setOnLoad(javaS);
        OAApplicationModule am = pageContext.getApplicationModule(webBean);
        //        OASubmitButtonBean submitBT = 
        //            (OASubmitButtonBean)webBean.findChildRecursive("saveBTN");
        //        submitBT.setRendered(false);

        if (pageContext.getParameter("createBTN") != null) {
            am.invokeMethod("createEmpRow");
            OACellFormatBean cfB = 
                (OACellFormatBean)webBean.findChildRecursive("image");
            cfB.setRendered(false);
            //            OAPageButtonBarBean pdfPBB = 
            //                (OAPageButtonBarBean)webBean.findChildRecursive("savePdf");
            //            pdfPBB.setRendered(false);
            //            OARawTextBean rawText = 
            //                (OARawTextBean)webBean.findIndexedChildRecursive("imgDataRT");
            //            OARawTextBean rawText1 = 
            //                (OARawTextBean)webBean.findIndexedChildRecursive("profilePicRT");
            //            rawText.setRendered(false);
            //            rawText1.setRendered(false);
        } else {
            XXSpel1VOImpl spelVo = 
                (XXSpel1VOImpl)am.findViewObject("XXSpel1VO1");
            if (!spelVo.isPreparedForExecution()) {
                spelVo.setMaxFetchSize(0);
                spelVo.executeQuery();
            }
            XXSpel1VORowImpl spelRow = (XXSpel1VORowImpl)spelVo.createRow();
            spelVo.insertRow(spelRow);
            spelRow.setNewRowState(Row.STATUS_INITIALIZED);
            if ("detail".equals(pageContext.getParameter("mode"))) {

                //do nothing//
                //                OAPageButtonBarBean navPBB = 
                //                    (OAPageButtonBarBean)webBean.findChildRecursive("navRN");
                //                navPBB.setRendered(false);
                //                
                OAMessageFileUploadBean im = 
                    (OAMessageFileUploadBean)webBean.findChildRecursive("photoMFU");
                im.setRendered(false);
                //                OASubmitButtonBean changeBtn = 
                //                    (OASubmitButtonBean)webBean.findChildRecursive("cancleBTN");
                //                changeBtn.setText("BACK");
                OATrainBean trainBean = 
                    (OATrainBean)webBean.findChildRecursive("region4");
                trainBean.setRendered(false);
                OANavigationBarBean pbb = 
                    (OANavigationBarBean)webBean.findChildRecursive("navBarRN");
                pbb.setRendered(false);
                OASubmitButtonBean changeBtn2 = 
                    (OASubmitButtonBean)webBean.findChildRecursive("saveBTN");
                changeBtn2.setText("DOWNLOAD PDF");
                OAHeaderBean changeHeader = 
                    (OAHeaderBean)webBean.findChildRecursive("createRN");
                changeHeader.setText("Details of Employee");

                String EmpNu = pageContext.getParameter("EmpNum");
                XXEmpDetEOVOImpl VO = 
                    (XXEmpDetEOVOImpl)am.findViewObject("XXEmpDetEOVO1");
                if (VO != null) {
                    VO.setWhereClause(null);
                    VO.setWhereClauseParams(null);
                    VO.setWhereClause("SNO=:1");
                    VO.setWhereClauseParam(0, EmpNu);
                    VO.executeQuery();
                }
                if (spelRow != null) {
                    spelRow.setdetailsdisable(Boolean.TRUE);
                }
                OAMessageStyledTextBean Employeeid1 = 
                    (OAMessageStyledTextBean)webBean.findChildRecursive("empNoMST");
                String Employeeid = (String)Employeeid1.getValue(pageContext);
                BlobDomain blobVal = null;
                if (Employeeid == null || "".equals(Employeeid)) {

                    if (pageContext.getSessionValue("empNoMST") != null && 
                        !"".equals(pageContext.getSessionValue("empNoMST"))) {
                        Employeeid = 
                                (String)pageContext.getSessionValue("empNoMST");
                    }
                }
                //        String Sno = (String)empMST.getValue(pageContext);
                //        setImage(pageContext, webBean, Sno);
                //        executeVO(pageContext, webBean, Sno);
                //        if (empMST == null || "".equals(empMST)) {
                //
                //            if (pageContext.getSessionValue("Employeeid") != null && 
                //                !"".equals(pageContext.getSessionValue("Employeeid"))) {
                //                empMST = (Number)pageContext.getSessionValue("Employeeid");
                //            }
                //        }

                if (Employeeid != null && !"".equals(Employeeid)) {
                    OARawTextBean ImgNew = 
                        (OARawTextBean)webBean.findIndexedChildRecursive("imgDataRT");
                    OAViewObject attachmentEOVO = 
                        (OAViewObject)am.findViewObject("XXEmpDetEOVO1");

                    if (attachmentEOVO != null) {
                        attachmentEOVO.setWhereClause(null);
                        attachmentEOVO.setWhereClauseParams(null);
                        attachmentEOVO.setWhereClause("Employeeid=:1");
                        attachmentEOVO.setWhereClauseParam(0, Employeeid);
                        attachmentEOVO.executeQuery();
                    }

                    int count = attachmentEOVO.getRowCount();

                    if (count > 0) {
                        XXEmpDetEOVORowImpl rowimpl = 
                            (XXEmpDetEOVORowImpl)attachmentEOVO.first();
                        if (rowimpl != null) {
                            blobVal = rowimpl.getEmpphoto();
                            if (blobVal != null) {
                                byte[] encoded = getEncodedBytes(blobVal);
                                ImgNew.setText(ImgNew.getText().replace("XXIMG", 
                                                                        "data:image/jpeg;base64," + 
                                                                        new String(encoded)));
                            }
                        }
                    }
                }

                //                OARawTextBean ImgNew = 
                //                    (OARawTextBean)webBean.findIndexedChildRecursive("imgDataRT");
                //                OAViewObject attachmentEOVO = 
                //                    (OAViewObject)am.findViewObject("XXEmpDetEOVO1");
                //
                //                if (attachmentEOVO != null) {
                //                    attachmentEOVO.setWhereClause(null);
                //                    attachmentEOVO.setWhereClauseParams(null);
                //                    attachmentEOVO.setWhereClauseParam(0, EmpNu);
                //                    attachmentEOVO.executeQuery();
                //                }
                //
                //                int count = VO.getRowCount();
                //
                //                if (count > 0) {
                //                    XXEmpDetEOVORowImpl rowimpl = 
                //                        (XXEmpDetEOVORowImpl)VO.first();
                //                    if (rowimpl != null) {
                //                        blobVal = rowimpl.getEmpphoto();
                //                        if (blobVal != null) {
                //                            byte[] encoded = getEncodedBytes(blobVal);
                //                            ImgNew.setText(ImgNew.getText().replace("XXIMG", 
                //                                                                    "data:image/jpeg;base64," + 
                //                                                                    new String(encoded)));
                //                        }
                //                    }

                //                if (pageContext.isLoggingEnabled(1))
                //                    pageContext.writeDiagnostics(this, 
                //                                                 "Entering processRequest..", 
                //                                                 1);
                //                Serializable[] param = 
                //                { pageContext.getTemporaryImageLocation() };
                //                pageContext.getApplicationModule(webBean).invokeMethod("initImg", 
                //                                                                       param); //initImg is the method we will create in AM
                //                OAImageBean oaimagebean = 
                //                    (OAImageBean)webBean.findIndexedChildRecursive("item1"); //id of image in the PG
                //                if (oaimagebean != null) {
                //                    oaimagebean.setAttributeValue(UIConstants.SOURCE_ATTR, 
                //                                                  new OADataBoundValueViewObject(oaimagebean, 
                //                                                                                 "ImageSource")); //ImageSource we created null column in the VO
                //                    oaimagebean.setWidth(100);
                //                    oaimagebean.setHeight(110);
                //                    oaimagebean.setBorderWidth(2);
                //                }
                //                if (pageContext.isLoggingEnabled(1))
                //                    pageContext.writeDiagnostics(this, 
                //                                                 "Leaving processRequest..", 
                //                                                 1);
            }
        }

    }

    /**
     * Procedure to handle form submissions for form elements in
     * a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processFormRequest(OAPageContext pageContext, 
                                   OAWebBean webBean) {
        super.processFormRequest(pageContext, webBean);
        OAApplicationModule am = pageContext.getApplicationModule(webBean);
        OAHeaderBean pageCreateEmpHder = 
            (OAHeaderBean)webBean.findChildRecursive("createRN");
        OAMessageStyledTextBean userId = 
            (OAMessageStyledTextBean)webBean.findChildRecursive("empNoMST");
        String userIdValue = (String)userId.getValue(pageContext);

        if (pageContext.getParameter("saveBTN") != null) {
            // this is calling apply method
            am.invokeMethod("apply");
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpSummaryPG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);
        }
        //this condition is for canceling the save details of employee
        if (pageContext.getParameter("cancleBTN") != null) {
            am.invokeMethod("rollbackChanges");
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpSummaryPG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);
            if ("Create Employee".equals(pageCreateEmpHder.getText())) {
                Connection conn = 
                    pageContext.getApplicationModule(webBean).getOADBTransaction().getJdbcConnection();
                //                String sqlStr = "ALTER SEQUENCE OAP_EMP_SEQ INCREMENT BY -1 ";
                String sqlStr2 = "ALTER SEQUENCE EMP_SL_NP INCREMENT BY -1 ";
                PreparedStatement stmt;
                //                try {
                //                    stmt = conn.prepareStatement(sqlStr);
                //                    stmt.executeQuery();
                //                    sqlStr = "select OAP_EMP_SEQ.nextval from dual ";
                //                    stmt = conn.prepareStatement(sqlStr);
                //                    stmt.executeQuery();
                //                    sqlStr = "ALTER SEQUENCE OAP_EMP_SEQ INCREMENT BY 1 ";
                //                    stmt = conn.prepareStatement(sqlStr);
                //                    stmt.executeQuery();
                //                } catch (SQLException e) {
                //                    ;
                //                }
                PreparedStatement stmt2;
                try {
                    stmt2 = conn.prepareStatement(sqlStr2);
                    stmt2.executeQuery();
                    sqlStr2 = "select EMP_SL_NP.nextval from dual ";
                    stmt2 = conn.prepareStatement(sqlStr2);
                    stmt2.executeQuery();
                    sqlStr2 = "ALTER SEQUENCE EMP_SL_NP INCREMENT BY 1 ";
                    stmt2 = conn.prepareStatement(sqlStr2);
                    stmt2.executeQuery();
                } catch (SQLException e) {
                    ;
                }

                //                if (pageContext.getParameter("uploadBTN") != null) {
                //                    upLoadFile(pageContext, webBean);
                //                    OAException confirmation =
                //                        new OAException("Photo Uploaded Successfully",
                //                                        OAException.CONFIRMATION);
                //                    pageContext.putDialogMessage(confirmation);
                //                }
            }
        }
        String event = pageContext.getParameter("event");
        DataObject sessionDictionary = 
            (DataObject)pageContext.getNamedDataObject("_SessionParameters");

        HttpServletResponse response = 
            (HttpServletResponse)sessionDictionary.selectValue(null, 
                                                               "HttpServletResponse");
        String contentDisposition = "attachment;filename=EmpOutput.pdf";
        response.setHeader("Content-Disposition", contentDisposition);
        response.setContentType("application/pdf");
        if (pageContext.getParameter("savepdf") != null) {


            try {

                ServletOutputStream os = response.getOutputStream();

                // Set the Output Report File Name and Content Type

//                String contentDisposition = 
//                    "attachment;filename=" + userIdValue + "empid.pdf";

                response.setHeader("Content-Disposition", contentDisposition);

                response.setContentType("application/pdf");

                // Get the Data XML File as the XMLNode

                XMLNode xmlNode = (XMLNode)am.invokeMethod("getEmpDataXML");

                ByteArrayOutputStream outputStream = 
                    new ByteArrayOutputStream();
                xmlNode.print(outputStream);
                //    System.out.println(outputStream.toString());  
                ByteArrayInputStream inputStream = 
                    new ByteArrayInputStream(outputStream.toByteArray());

                ByteArrayOutputStream pdfFile = new ByteArrayOutputStream();

                TemplateHelper.processTemplate(((OADBTransactionImpl)pageContext.getApplicationModule(webBean).getOADBTransaction()).getAppsContext(), 
                                               "PER", "XXEmpDetDT", 
                                               ((OADBTransactionImpl)pageContext.getApplicationModule(webBean).getOADBTransaction()).getUserLocale().getLanguage(), 
                                               ((OADBTransactionImpl)pageContext.getApplicationModule(webBean).getOADBTransaction()).getUserLocale().getCountry(), 
                                               inputStream, 
                                               TemplateHelper.OUTPUT_TYPE_PDF, 
                                               null, pdfFile);


                // Write the PDF Report to the HttpServletResponse object and flush.

                byte[] b = pdfFile.toByteArray();

                response.setContentLength(b.length);

                os.write(b, 0, b.length);

                os.flush();

                os.close();

                pdfFile.flush();

                pdfFile.close();

            }

            catch (Exception e)

            {

                response.setContentType("text/html");
                System.out.println(e.getMessage());
                throw new OAException(e.getMessage(), OAException.ERROR);

            }

            pageContext.setDocumentRendered(true);

        }


        //            try {
        //
        //                ServletOutputStream os = response.getOutputStream();
        //
        //
        //                //Calling RTF Processor
        //                //RTF Processor generate XSL
        //                RTFProcessor rtfProcessor = 
        //                    new RTFProcessor("C:\\EMPTemplate.rtf");
        //                ByteArrayOutputStream xlsOutputStream = 
        //                    new ByteArrayOutputStream();
        //                rtfProcessor.setOutput(xlsOutputStream);
        //                rtfProcessor.process();
        //
        //
        //                // Get the XML Data as the XMLNode from VO
        //                XMLNode xmlNode = (XMLNode)am.invokeMethod("getEmpDataXML");
        //                ByteArrayOutputStream localByteArrayOutputStream = 
        //                    new ByteArrayOutputStream();
        //                ByteArrayInputStream xmlInputStream = 
        //                    new ByteArrayInputStream(localByteArrayOutputStream.toByteArray());
        //
        //                //Calling FO Processor
        //                //FO processor take XML data and RTF as XSL and generate PDF output
        //                FOProcessor processor = new FOProcessor();
        //                ByteArrayOutputStream pdfOutputStream = 
        //                    new ByteArrayOutputStream();
        //                processor.setData(xmlInputStream); //set xml input Stream
        //                ByteArrayInputStream xlsInputStream = 
        //                    new ByteArrayInputStream(xlsOutputStream.toByteArray());
        //                processor.setTemplate(xlsInputStream); //set xsl input file
        //                processor.setOutput(pdfOutputStream);
        //                processor.setOutputFormat(FOProcessor.FORMAT_PDF);
        //
        //                try {
        //                    processor.generate();
        //                } catch (XDOException e) {
        //                    e.printStackTrace();
        //                }
        //
        //                // Write the PDF Report to the HttpServletResponse object and flush.
        //                byte[] b = pdfOutputStream.toByteArray();
        //                response.setContentLength(b.length);
        //                os.write(b, 0, b.length);
        //                os.flush();
        //                os.close();
        //                pdfOutputStream.flush();
        //                pdfOutputStream.close();
        //
        //            } catch (Exception e) {
        //                throw new OAException("Aman Ranjan=" + e.getMessage(), 
        //                                      OAException.ERROR);
        //            }
    }
    //
    //    private static byte[] getBytes(InputStream is) throws IOException {
    //        int len;
    //        int size = 1024;
    //        byte[] buf;
    //
    //        if (is instanceof ByteArrayInputStream) {
    //            size = is.available();
    //            buf = new byte[size];
    //            len = is.read(buf, 0, size);
    //        } else {
    //            ByteArrayOutputStream bos = new ByteArrayOutputStream();
    //            buf = new byte[size];
    //            while ((len = is.read(buf, 0, size)) != -1)
    //                bos.write(buf, 0, len);
    //            buf = bos.toByteArray();
    //        }
    //        return buf;
    //
    //    }


    /*  ?   */
    //        }
    //        /* 179 */return img;
    //        /*     */
    //    }
    //    /*     */
    //    /*     */
    //
    //    private byte[] getEncodedBytes(BlobDomain data) {
    //        /* 186 */byte[] blobAsBytes = data.toByteArray();
    //        /* 187 */Base64 codec = new Base64();
    //        /* 188 */byte[] encoded = Base64.encodeBase64(blobAsBytes);
    //        /*     */
    //        /* 190 */return encoded;
    //        /*     */
    //    }
    //    /*     */
    //    /*     */
    //
    //    private void setImage(OAPageContext pageContext, OAWebBean webBean, 
    //                          String employeeNumber) {
    //        /* 194 */byte[] imageData = null;
    //        /*     */
    //        /* 196 */BlobDomain imgBlobData = 
    //            getBlobData(pageContext, webBean, employeeNumber);
    //        /* 198 */if (imgBlobData != null) {
    //            /* 199 */imageData = getEncodedBytes(imgBlobData);
    //            /*     */
    //        }
    //        /* 200 */OAImageBean personImage = 
    //            (OAImageBean)webBean.findChildRecursive("EmpImg");
    //        /* 202 */if (imageData != null) {
    //            /* 203 */personImage.setAttributeValue(UIConstants.SOURCE_ATTR, 
    //                                                   "data:image/jpeg;base64," + 
    //                                                   new String(imageData));
    //            /*     */
    //        } else {
    //            /* 207 */personImage.setAttributeValue(UIConstants.SOURCE_ATTR, 
    //                                                   "/OA_MEDIA/emploee_deafult_image.gif");
    //            /*     */
    //        }
    //        /*     */
    //    }

    public byte[] getEncodedBytes(BlobDomain data) {
        byte[] blobAsBytes = data.toByteArray();
        Base64 codec = new Base64();
        byte[] encoded = Base64.encodeBase64(blobAsBytes);
        return encoded;
    }

    public BlobDomain getBlobData(OAPageContext pageContext, OAWebBean webBean, 
                                  String Employeeid) {
        BlobDomain img = null;
        XXEmpDetAMImpl am = 
            (XXEmpDetAMImpl)pageContext.getApplicationModule(webBean);
        if (am != null) {
            OAViewObject vo = (OAViewObject)am.findViewObject("XXEmpDetEOVO1");
            vo.setWhereClause(null);
            vo.setWhereClauseParams(null);
            vo.setWhereClause("Employeeid=1452");
            vo.executeQuery();
            vo.reset();
            if (vo.getRowCount() > 0) {
                OARow row = (OARow)vo.next();
                img = (BlobDomain)row.getAttribute("Empphoto");
            }
        }
        return img;
    }
}
