/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package xxnewemp.oracle.apps.per.selfservice.employee.webui;

import java.io.IOException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OAViewRowImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.apps.fnd.framework.webui.beans.layout.OAQueryBean;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;


import oracle.jbo.AttributeDef;

import oracle.jbo.Row;
import oracle.jbo.domain.Date;

import xxnewemp.oracle.apps.per.selfservice.employee.server.XXEmpDetEOVOImpl;
import xxnewemp.oracle.apps.per.selfservice.employee.server.XXEmpDetEOVORowImpl;

/**
 * Controller for ...
 */
public class XXEmpSummaryCO extends OAControllerImpl {
    public static final String RCS_ID = "$Header$";
    public static final boolean RCS_ID_RECORDED = 
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

    /**
     * Layout and page setup logic for a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
        super.processRequest(pageContext, webBean);
        OAApplicationModule am = pageContext.getApplicationModule(webBean);
        XXEmpDetEOVOImpl summaryVO = 
            (XXEmpDetEOVOImpl)am.findViewObject("XXEmpDetEOVO1");
        if (summaryVO != null) {
            summaryVO.setWhereClause(null);
            summaryVO.setWhereClauseParams(null);
            summaryVO.executeQuery();
        }
        OAQueryBean querybean = 
            (OAQueryBean)webBean.findIndexedChildRecursive("findQR");
        querybean.clearSearchPersistenceCache(pageContext);

    }

    /**
     * Procedure to handle form submissions for form elements in
     * a region.
     * @param pageContext the current OA page context
     * @param webBean the web bean corresponding to the region
     */
    public void processFormRequest(OAPageContext pageContext, 
                                   OAWebBean webBean) {
        super.processFormRequest(pageContext, webBean);
        if (pageContext.getParameter("createBTN") != null) {
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpCreatePG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);

        }
        if (pageContext.getParameter("delEmpMSI") != null) {
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpDelRecordsPG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);

        }
        if ("detail".equals(pageContext.getParameter(EVENT_PARAM))) {
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpCreatePG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);
        }
        if ("edit".equals(pageContext.getParameter(EVENT_PARAM))) {
            pageContext.setForwardURL("OA.jsp?page=/xxnewemp/oracle/apps/per/selfservice/employee/webui/XXEmpCreatePG", 
                                      null, 
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                      null, null, true, 
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES, 
                                      OAWebBeanConstants.IGNORE_MESSAGES);
        }
        OAApplicationModule am = pageContext.getApplicationModule(webBean);
        OAViewObject vo = (OAViewObject)am.findViewObject("XXEmpDetEOVO1");


        String rowRef = 
            pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);


        OARow row = (OARow)am.findRowByRef(rowRef);
        if ("delete".equals(pageContext.getParameter(EVENT_PARAM))) {
            OAException message = 
                new OAException("Are you sure you want to delete this record?", 
                                OAException.WARNING);
            //            pageContext.putDialogMessage(message);


            OADialogPage dialogPage = 
                new OADialogPage(OAException.WARNING, message, null, "Hello", 
                                 "Hello");


            //            String yes =
            //                pageContext.getMessage("for delete press", "YES", null);
            //            String no =
            //                pageContext.getMessage("for revert your operation press", "No",
            //                                       null);


            String yes = "Yes";
            String no = "No";


            dialogPage.setOkButtonItemName("DeleteYesButton");


            dialogPage.setOkButtonToPost(true);
            dialogPage.setNoButtonToPost(true);
            dialogPage.setPostToCallingPage(true);


            dialogPage.setOkButtonLabel(yes);
            dialogPage.setNoButtonLabel(no);


            pageContext.redirectToDialogPage(dialogPage);
        } else if (pageContext.getParameter("DeleteYesButton") != null) {
            am.invokeMethod("deleteRecord", null);
//            OAMessageStyledTextBean Employeeid1 = 
//                (OAMessageStyledTextBean)webBean.findChildRecursive("empNoMST");
//            String Employeeid = (String)Employeeid1.getValue(pageContext);
//            //            am.invokeMethod("getRecords");
//            OAViewObject attachmentEOVO = (OAViewObject)am.findViewObject("XXEmpDetEOVO1");
//            if (attachmentEOVO != null) {
//                attachmentEOVO.setWhereClause(null);
//                attachmentEOVO.setWhereClauseParams(null);
//                attachmentEOVO.setWhereClause("Employeeid=:1");
//                attachmentEOVO.setWhereClauseParam(0, Employeeid);
//                attachmentEOVO.executeQuery();
//            }
//        
//            Row rowmore = attachmentEOVO.getCurrentRow();
//            
//            if (count > 0) {
//                XXEmpDetEOVORowImpl rowimpl = 
//                    (XXEmpDetEOVORowImpl)attachmentEOVO.first();
//                if (rowimpl != null) {
//                    blobVal = rowimpl.getEmpphoto();
//                    if (blobVal != null) {
//                        byte[] encoded = getEncodedBytes(blobVal);
//                        ImgNew.setText(ImgNew.getText().replace("XXIMG", 
//                                                                "data:image/jpeg;base64," + 
//                                                                new String(encoded)));
//                    }
//                }
//            }
            OAMessageStyledTextBean conf = 
                (OAMessageStyledTextBean)webBean.findChildRecursive("Employeeid");
            String cnf = (String)conf.getValue(pageContext);
            OAException confirmation = 
                new OAException( "Employee_ID-"+cnf+" "+" Record is deleted Successfully.", 
                                OAException.CONFIRMATION);
            pageContext.putDialogMessage(confirmation);


        }
        if (pageContext.getParameter("ExportBTN") != null) {
            /* Specify the hidden attribute column names*/
            String ss[] = { null };
            /* Call the method to export data */
            downloadCsvFile(pageContext, "XXEmpDetEOVO1", null, "MAX", ss);
        }
    }

    public void downloadCsvFile(OAPageContext pageContext, 
                                String view_inst_name, 
                                String file_name_without_ext, String max_size, 
                                String[] hidden_attrib_list) {
        /*
    ***********************************
    ** Specified Columns name *********
    **********************************
    */

        String voFieldNames[] = 
        { "SL.NO", "EMPLOYEE_ID", "FULLNAME", "DEPARTMENT", "DOB", "HIRE_DATE", 
          "MOBILE_NO", "EMAIL_ID", "ADDRESS", "DESIGNATION", "NATIONALITY" };
        /* End of column names */

        OAViewObject v = 
            (OAViewObject)pageContext.getRootApplicationModule().findViewObject(view_inst_name);
        if (v == null) {
            throw new OAException("Could not find View object instance " + 
                                  view_inst_name + " in root AM.");
        }
        if (v.getFetchedRowCount() == 0) {
            throw new OAException("There is no data to export.");
        }
        String file_name = "Employee_Details_Report";
        if (file_name_without_ext != null && 
            !"".equals(file_name_without_ext)) {
            file_name = file_name_without_ext;
        }
        HttpServletResponse response = 
            (HttpServletResponse)pageContext.getRenderingContext().getServletResponse();
        response.setContentType("application/text");
        response.setHeader("Content-Disposition", 
                           "attachment; filename=" + file_name + ".csv");
        ServletOutputStream pw = null;
        try {
            pw = response.getOutputStream();
            int j = 0;
            int k = 0;
            boolean bb = true;
            System.out.println("inside try block");
            if (max_size == null || "".equals(max_size)) {
                k = 
  Integer.parseInt(pageContext.getProfile("VO_MAX_FETCH_SIZE"));
                bb = false;
            } else if ("MAX".equals(max_size)) {
                bb = true;
            } else {
                k = Integer.parseInt(max_size);
                bb = false;
            }
            AttributeDef a[] = v.getAttributeDefs();
            StringBuffer cc = new StringBuffer();
            ArrayList exist_list = new ArrayList();
            for (int l = 0; l < a.length; l++) {
                boolean zx = true;
                if (hidden_attrib_list != null) {
                    for (int z = 0; z < hidden_attrib_list.length; z++) {
                        if (a[l].getName().equals(hidden_attrib_list[z])) {
                            zx = false;
                            exist_list.add(String.valueOf(a[l].getIndex()));
                        }
                    }

                }
            }

            for (int l = 0; l < voFieldNames.length; l++) {
                boolean zx = true;
                if (zx) {
                    cc.append("\"" + (voFieldNames[l]) + "\"");
                    cc.append(",");
                }
            }

            String header_row = cc.toString();
            pw.println(header_row);
            OAViewRowImpl row = (OAViewRowImpl)v.first();
            do {
                if (row == null) {
                    break;
                }
                j++;
                StringBuffer b = new StringBuffer();
                for (int i = 0; i < v.getAttributeCount(); i++) {
                    boolean cv = true;
                    for (int u = 0; u < exist_list.size(); u++) {
                        if (String.valueOf(i).equals(exist_list.get(u).toString())) {
                            cv = false;
                        }
                    }

                    if (cv) {
                        Object o = row.getAttribute(i);
                        if (o != null) {
                            if (o.getClass().equals(Class.forName("oracle.jbo.domain.Date"))) {
                                Date dt = (Date)o;
                                java.sql.Date ts = dt.dateValue();
                                SimpleDateFormat displayDateFormat = 
                                    new SimpleDateFormat("dd-MMM-yyyy");
                                String convertedDateString = 
                                    displayDateFormat.format(ts);
                                b.append("\"" + convertedDateString + "\"");
                            } else {
                                b.append("\"" + o.toString() + "\"");
                            }
                        } else {
                            b.append("\"\"");
                        }
                        b.append(",");
                    }
                }

                String final_row = b.toString();
                pw.println(final_row);
                if (!bb && j == k) {
                    break;
                }
                row = (OAViewRowImpl)v.next();
            } while (true);
        } catch (Exception e) {
            e.printStackTrace();
            throw new OAException("Unexpected Exception occurred.Exception Details :" + 
                                  e.toString());
        }
        pageContext.setDocumentRendered(false);
        try {
            pw.flush();
            pw.close();
        } catch (IOException ioexception) {
            ioexception.printStackTrace();
            throw new OAException("Unexpected Exception occurred.Exception Details :");
            //            ioexception.toString();

        }
        try {
            pw.flush();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw new OAException("Unexpected Exception occurred.Exception Details :");
            //            e.toString();

        }

    }
}

